package cn.imtianx.android.versions

/**
 * <pre>
 *     @desc: versions
 * </pre>
 * @author imtianx
 * @email imtianx@gmail.com
 * @date 1/24/21 5:28 PM
 */
@Suppress("SpellCheckingInspection")
object Versions {

    object BuildConfig {

        object Sdk {
            const val _14 = 14
            const val _15 = 15
            const val _16 = 16
            const val _17 = 17
            const val _18 = 18
            const val _19 = 19
            const val _20 = 20
            const val _21 = 21
            const val _22 = 22
            const val _23 = 23
            const val _24 = 24
            const val _25 = 25
            const val _26 = 26
            const val _27 = 27
            const val _28 = 28
            const val _29 = 28
            const val _30 = 30
            const val _3002 = "30.0.2"
        }
    }

    object Kotlin {
        // @formatter:off
        const val _1_4_21 = "1.4.21"
        const val kotlinStdLib = "org.jetbrains.kotlin:kotlin-stdlib:$_1_4_21"
        const val kotlinCoroutionsCore = "org.jetbrains.kotlinx:kotlinx-coroutines-core:1.4.2"
        const val kotlinReflect = "org.jetbrains.kotlin:kotlin-reflect:1.4.21"
        // @formatter:on
    }

    object Gradle {
        const val _4_1_2 = "4.1.2"
    }

    object Testing {
        const val junit = "junit:junit:4.12"
        const val testExt = "androidx.test.ext:junit:1.1.1"
        const val testEspressoCore = "androidx.test.espresso:espresso-core:3.2.0"
    }

    object AndroidX {
        // @formatter:off
        const val appcompat = "androidx.appcompat:appcompat:1.2.0"
        const val coreKtx = "androidx.core:core-ktx:1.3.2"
        const val fragmentKtx = "androidx.fragment:fragment-ktx:1.2.5"
        const val material = "com.google.android.material:material:1.2.1"
        const val multidex = "androidx.multidex:multidex:2.0.1"
        const val constraintlayout = "androidx.constraintlayout:constraintlayout:2.0.4"
        const val recyclerview = "androidx.recyclerview:recyclerview:1.1.0"
        const val viewPager2 = "androidx.viewpager2:viewpager2:1.0.0"

        // lifecycle
        const val lifeCycleRuntime =  "androidx.lifecycle:lifecycle-runtime:2.2.0"
        const val lifeCycleRuntimeKtx =  "androidx.lifecycle:lifecycle-runtime-ktx:2.3.0"
        const val lifeCycleCommonJava8 =  "androidx.lifecycle:lifecycle-common-java8:2.2.0"
        const val lifeCycleViewModel =  "androidx.lifecycle:lifecycle-viewmodel:2.2.0"
        const val lifeCycleViewModelKtx =  "androidx.lifecycle:lifecycle-viewmodel-ktx:2.3.0"
        const val lifeCycleLiveData =  "androidx.lifecycle:lifecycle-livedata:2.2.0"

        // @formatter:on
    }

    object Library {
        // @formatter:off
        const val utilCodex = "com.blankj:utilcodex:1.30.5"
        const val baseRecyclerViewAdapterHelper = "com.github.CymChad:BaseRecyclerViewAdapterHelper:3.0.6"
        const val retrofit = "com.squareup.retrofit2:retrofit:2.9.0"
        const val retrofitConverGson = "com.squareup.retrofit2:converter-gson:2.9.0"
        const val gson = "com.google.code.gson:gson:2.8.6"
        const val glide = "com.github.bumptech.glide:glide:4.11.0"
        const val glideCompiler = "com.github.bumptech.glide:compiler:4.11.0"
        const val permissionx = "com.permissionx.guolindev:permissionx:1.4.0"
        const val mmkv = "com.tencent:mmkv-static:1.2.7"
        const val koinScope = "org.koin:koin-androidx-scope:2.2.2"
        const val koinViewmodel = "org.koin:koin-androidx-viewmodel:2.2.2"
        const val koinFragment = "org.koin:koin-androidx-fragment:2.2.2"
        const val dialogs = "com.afollestad.material-dialogs:lifecycle:3.3.0"
        const val dialogsCore = "com.afollestad.material-dialogs:core:3.3.0"

        const val immersionbar = "com.gyf.immersionbar:immersionbar:3.0.0"
        const val immersionbarComponents = "com.gyf.immersionbar:immersionbar-components:3.0.0"
        const val immersionbarKtx = "com.gyf.immersionbar:immersionbar-ktx:3.0.0"

        const val smartRefresh = "com.scwang.smart:refresh-layout-kernel:2.0.3"
        const val smartRefreshHeaderClassic = "com.scwang.smart:refresh-header-classics:2.0.3"
        const val smartRefreshFooterClassic = "com.scwang.smart:refresh-footer-classics:2.0.3"


        // @formatter:on
    }
}