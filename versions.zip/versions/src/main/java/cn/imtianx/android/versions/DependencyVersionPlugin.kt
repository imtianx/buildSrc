package cn.imtianx.android.versions

import org.gradle.api.Plugin
import org.gradle.api.Project

/**
 * <pre>
 *     @desc:
 * </pre>
 * @author imtianx
 * @email imtianx@gmail.com
 * @date 1/24/21 5:21 PM
 */
class DependencyVersionPlugin : Plugin<Project> {
    override fun apply(project: Project) {
    }
}